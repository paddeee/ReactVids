/** @jsx React.DOM */
var CatalogItem =
  React.createClass({
    render:function(){
      return ()
    }
  });
module.exports = CatalogItem;
