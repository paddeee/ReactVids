/** @jsx React.DOM */
var Template =
  React.createClass({
    render:function(){
      return  ()
    }
  });
module.exports = Template;
