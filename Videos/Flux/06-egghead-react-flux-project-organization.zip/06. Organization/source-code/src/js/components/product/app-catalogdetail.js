/** @jsx React.DOM */
var CatalogDetail =
  React.createClass({
    render:function(){
      return ()
    }
  });
module.exports = CatalogDetail;
