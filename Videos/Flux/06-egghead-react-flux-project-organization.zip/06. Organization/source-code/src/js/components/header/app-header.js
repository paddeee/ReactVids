/** @jsx React.DOM */
var Header =
  React.createClass({
    render:function(){
      return ()
    }
  });
module.exports = Header;
