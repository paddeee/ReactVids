/** @jsx React.DOM */
var React = require('react')
var CatalogDetail =
  React.createClass({
    render:function(){
      return null
    }
  });
module.exports = CatalogDetail;
