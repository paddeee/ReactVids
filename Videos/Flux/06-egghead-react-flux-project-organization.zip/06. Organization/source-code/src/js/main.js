/** @jsx React.DOM */
var APP = require('./components/app');
var React = require('react');

React.renderComponent(
  <APP />,
  document.getElementById('main'));
