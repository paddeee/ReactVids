/** @jsx React.DOM */
var CartSummary =
  React.createClass({
    render:function(){
      return ()
    }
  });
module.exports = CartSummary;
